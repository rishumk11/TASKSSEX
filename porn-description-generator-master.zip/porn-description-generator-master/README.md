# Porn Description Generator

#### Generates new porn descriptions based on an edited dataset of xhamster video descriptions uploaded between 2007-2016. The complete dataset is available from <a href="https://sexualitics.github.io/" target="_blank">Sexualitics.</a>

*Script written in Python3 using the Markovify package.*<br>
*Web app built using Flask.*

### <a href="https://porn-description-generator.herokuapp.com/" target="_blank">Live demo<a>

<br>
<img src="screenshots/porn-description-generator-screenshot.jpg" width="600">
